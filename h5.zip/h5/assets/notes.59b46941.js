const e=""+new URL("notes-414ce9a4.png",import.meta.url).href;export{e as _};
