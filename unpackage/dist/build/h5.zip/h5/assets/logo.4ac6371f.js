const o=""+new URL("logo-0f14bb71.png",import.meta.url).href;export{o as _};
