const e=""+new URL("answer-8a654d58.png",import.meta.url).href;export{e as _};
