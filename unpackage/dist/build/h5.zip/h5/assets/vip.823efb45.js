const e=""+new URL("vip-f0fcfcee.png",import.meta.url).href;export{e as _};
